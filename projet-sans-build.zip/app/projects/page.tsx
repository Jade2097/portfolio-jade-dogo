export const metadata = { title: "Projets" };

export default function ProjetsPage() {
  return (
    <main className="container">
      <h1>Mes projets</h1>
      <p>Quelques réalisations récentes.</p>
      {/* Remplace ci-dessous par une vraie liste */}
      <ul>
        <li>Projet 1</li>
        <li>Projet 2</li>
      </ul>
    </main>
  );
}

