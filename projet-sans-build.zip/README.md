# Portfolio — Jade DOGO

Portfolio personnel (Next.js App Router).
- Projets
- À propos
- Contact

## Démarrer
npm i
npm run dev

## Déploiement
Vercel (Framework: Next.js). Aucune autre page que le portfolio.

